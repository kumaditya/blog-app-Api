package in.sp.blog.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import in.sp.blog.Entities.User;

public interface UserRepo extends JpaRepository<User, Integer> {

}
