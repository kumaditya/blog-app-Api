package in.sp.blog.exceptions;

public class ResourceNotFoundException extends RuntimeException{
	
	String ResourceName;
	String fieldName;
	long fieldvalue;
	public ResourceNotFoundException(String resourceName, String fieldName, long fieldvalue) {
		
		this.ResourceName = resourceName;
		this.fieldName = fieldName;
		this.fieldvalue = fieldvalue;
	}
	
	

}
