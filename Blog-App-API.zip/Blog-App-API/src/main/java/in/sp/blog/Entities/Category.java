package in.sp.blog.Entities;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "category")
public class Category {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer categoryId;
	
	@Column(name = "tittle")
	private String categorytitttle;
	
	public Category() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategorytitttle() {
		return categorytitttle;
	}

	public void setCategorytitttle(String categorytitttle) {
		this.categorytitttle = categorytitttle;
	}

	public String getCategoryDescripton() {
		return categoryDescripton;
	}

	public void setCategoryDescripton(String categoryDescripton) {
		this.categoryDescripton = categoryDescripton;
	}

	@Column(name = "description")
	private String categoryDescripton;
	

}
