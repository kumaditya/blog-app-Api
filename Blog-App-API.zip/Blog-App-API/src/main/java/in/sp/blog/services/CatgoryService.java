package in.sp.blog.services;

import java.util.List;

import in.sp.blog.payloads.CategoryDto;

public interface CatgoryService {
	
  // create 
	
	public CategoryDto createCategory(CategoryDto cdto);
	
	//update
	
	public CategoryDto updateCategory(CategoryDto cdto ,int cateid);
	
	//delete
	
	public void deleteCategory(int id);
	
	// get all
	
	public List<CategoryDto> getALLCategory();
	
	// get single
	public CategoryDto getSingleCategory(int catid);

}
