package in.sp.blog.payloads;

import jakarta.persistence.Id;

public class CategoryDto {
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCategorytittle() {
		return categorytittle;
	}
	public void setCategorytittle(String categorytittle) {
		this.categorytittle = categorytittle;
	}
	public String getCategorydescription() {
		return categorydescription;
	}
	public void setCategorydescription(String categorydescription) {
		this.categorydescription = categorydescription;
	}
	
	
	private Integer id;
	private String categorytittle;
	private String categorydescription;

}
