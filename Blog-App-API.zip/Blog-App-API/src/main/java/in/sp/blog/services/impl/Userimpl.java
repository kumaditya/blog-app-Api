package in.sp.blog.services.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.sp.blog.Entities.User;
import in.sp.blog.exceptions.ResourceNotFoundException;
import in.sp.blog.payloads.UserDto;
import in.sp.blog.repository.UserRepo;
import in.sp.blog.services.UserService;

@Service
public class Userimpl implements UserService {

	@Autowired
	private UserRepo userrepo;
	
	@Autowired
	private ModelMapper modelmapper;

	@Override
	public UserDto createUser(UserDto userdto) {

		User user = this.DtoToUser(userdto);
		User saveduser = userrepo.save(user);

		return this.userToUserDto(saveduser);
	}

	@Override
	public UserDto updateSUer(UserDto userdto, Integer id) {

		User user = this.userrepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("User", "id", id));

		user.setName(userdto.getName());
		user.setEmail(userdto.getEmail());
		user.setPassword(userdto.getPassword());
		user.setAbout(userdto.getAbout());

		User updateuser = this.userrepo.save(user);
		return this.userToUserDto(updateuser);
	}

	@Override
	public UserDto getUserById(Integer userid) {
		User user = this.userrepo.findById(userid)
				.orElseThrow(() -> new ResourceNotFoundException("User", "id", userid));
		return this.userToUserDto(user);
	}

	@Override
	public List<UserDto> getAllUser() {
		
	List<User> users=	this.userrepo.findAll();
	
	List<UserDto> userdto=users.stream().map(user->this.userToUserDto(user)).collect(Collectors.toList());
		
		
		return userdto;
	}

	@Override
	public void deleteUser(Integer id) {
		
	User user=	this.userrepo.findById(id).orElseThrow(()-> new ResourceNotFoundException("User", "ID", id));
	this.userrepo.delete(user);
		

	}

	public User DtoToUser(UserDto userdto) {
		User user = this.modelmapper.map(userdto ,User.class);
		//user.setId(userdto.getId());
		//user.setName(userdto.getName());
		//user.setEmail(userdto.getEmail());
		//user.setPassword(userdto.getPassword());
		//user.setAbout(userdto.getAbout());

		return user;
	}

	public UserDto userToUserDto(User user) {
		UserDto userdto = this.modelmapper.map(user, UserDto.class);
		//userdto.setId(user.getId());
		//userdto.setName(user.getName());
		//userdto.setEmail(user.getEmail());
		//userdto.setPassword(user.getPassword());
		//userdto.setAbout(user.getAbout());

		return userdto;
	}

}
