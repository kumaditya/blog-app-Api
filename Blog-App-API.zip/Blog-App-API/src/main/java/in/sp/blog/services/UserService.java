package in.sp.blog.services;

import java.util.List;

import in.sp.blog.payloads.UserDto;
import jakarta.persistence.criteria.CriteriaBuilder.In;

public interface UserService {
	
	
	UserDto createUser(UserDto user);
	UserDto updateSUer(UserDto user,Integer id);
	UserDto getUserById(Integer userid);
	
	List<UserDto> getAllUser();
	
	void deleteUser(Integer id);
	
	
	
	
	
	

}
