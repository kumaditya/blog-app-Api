package in.sp.blog.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import in.sp.blog.payloads.UserDto;
import in.sp.blog.services.UserService;


@RestController
@RequestMapping("/api/users")
@Validated
public class UserContoller {
	
	@Autowired
	private UserService userservice;
	
	
	//POST Create User
	@PostMapping("/")
	public ResponseEntity<UserDto>  createUser(@Valid @RequestBody UserDto userdto)	{
		
		UserDto createduser=this.userservice.createUser(userdto);
		
		return new ResponseEntity<>(createduser ,HttpStatus.CREATED);
		
		
	}
	
	// PUT Method for update User
	@PutMapping("/{userID}")
	public  ResponseEntity<UserDto> updateUser(@Valid @RequestBody UserDto userdto,@PathVariable("userID") int uid)
	
	{
		UserDto updatesUSer=this.userservice.updateSUer(userdto, uid);
		
		return ResponseEntity.ok(updatesUSer);
	}
	
	//Delete USer
	@DeleteMapping("/{UserID}")
	public void deleteUSer(@PathVariable("UserID") int uid)
	{
		this.userservice.deleteUser(uid);
	}
	
	//GET ALL User
	
	@GetMapping("/")
	public ResponseEntity<List<UserDto>> getAllUsers()
	{
		return ResponseEntity.ok(this.userservice.getAllUser());
	}
	
	@GetMapping("/{userID}")
	public ResponseEntity<UserDto> getUser(@PathVariable int userID)
	{
		return ResponseEntity.ok(this.userservice.getUserById(userID));
	}

}
