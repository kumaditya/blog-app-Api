package in.sp.blog.services.impl;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.annotation.JsonCreator.Mode;

import in.sp.blog.Entities.Category;
import in.sp.blog.payloads.CategoryDto;
import in.sp.blog.repository.CategoryRepo;
import in.sp.blog.services.CatgoryService;


@Service
public class CategoryImpl implements CatgoryService{

	@Autowired
	private CategoryRepo catrepo;
	
	@Autowired
	private ModelMapper modelmapper;
	
	@Override
	public CategoryDto createCategory(CategoryDto cdto) {
		
		Category cat=this.modelmapper.map(cdto, Category.class);
		
		Category addedcat= this.catrepo.save(cat);
		
		
		return this.modelmapper.map(addedcat, CategoryDto.class);
	}

	@Override
	public CategoryDto updateCategory(CategoryDto cdto, int cateid) {
		
		return null;
	}

	@Override
	public void deleteCategory(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<CategoryDto> getALLCategory() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CategoryDto getSingleCategory(int catid) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
